import streamlit as st
import numpy as np
import pickle
import logging
import pymongo

logging.basicConfig(filename='info.txt', 
                    level=logging.INFO,
                    filemode='a',
                    format='%(asctime)s %(levelname)s-%(message)s',
                    datefmt='%Y-%m-%d %H:%M-%S')

model = pickle.load(open('model.pkl', 'rb'))

st.set_page_config(page_title="Zomato Rating Prediction", page_icon=":smiley:")

def predict(features):
    '''
    Function to predict the restaurant rating.
    '''
    final_features = np.array(features).reshape(1, -1)
    prediction = model.predict(final_features)
    return round(prediction[0], 1)

def main():
    st.title("Zomato Rating Prediction")
    st.markdown("### Please enter the following details:")
    
    online_order = st.text_input("Online Order")
    book_table = st.text_input("Book Table")
    votes = st.text_input("Votes")
    location = st.text_input("Location")
    restaurant_type = st.text_input("Restaurant Type")
    dishes_liked = st.text_input("Dishes Liked")
    cuisines = st.text_input("Cuisines")
    cost = st.text_input("Cost For 2 Person")
    
    
    if st.button("Predict Rating"):
        features = [online_order, book_table, votes, location, restaurant_type, dishes_liked, cuisines, cost, restaurant_type]
        prediction = predict(features)
        st.success(f"Predicted Rating: {prediction}")

        # Log the input data
        logging.info("Successfully retrieved information from user...!")

        # Connect to MongoDB
        default_connection_url ="mongodb+srv://arnav:iafsu30mki@cluster0.wzrwu.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
        client = pymongo.MongoClient(default_connection_url)
        logging.info("Database connection established..!")

        # Insert input data into MongoDB
        db_name = "zomato"
        database = client[db_name]
        collection_name = "user_details"
        collection = database[collection_name]
        info = {
            'Online Order': online_order,
            'Book Table': book_table,
            'Votes': votes,
            'Location': location,
            'Restaurant Type': restaurant_type,
            'Dishes Liked': dishes_liked,
            'Cuisines': cuisines,
            'Cost For 2 Person': cost,
            'Type': restaurant_type,
            'Rating Prediction': prediction
        }
        collection.insert_one(info)
        logging.info("Data inserted into MongoDB.")

        # Log the prediction
        logging.info("Successfully predicted the rating.")

if __name__ == "__main__":
    main()
